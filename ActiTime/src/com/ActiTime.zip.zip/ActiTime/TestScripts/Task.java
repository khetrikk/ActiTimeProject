package com.ActiTime.TestScripts;

import org.testng.annotations.Test;

import com.ActiTime.GenericLibrary.Baseclass;
import com.ActiTime.ObjectRepository.HomePage;
//10-05-23.
public class Task extends Baseclass{
    @Test
    public void createCustomer() {
    	HomePage hp=new HomePage(driver);
    	hp.getTasktab().click();
    }
}
